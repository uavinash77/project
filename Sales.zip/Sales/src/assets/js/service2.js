(function() {
  if (typeof _bsa !== 'undefined' && _bsa) {
    _bsa.init('flexbar', 'CKYDEKQI', 'placement:thepowerofserverlessinfo');
  }
})();
