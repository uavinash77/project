import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactustab',
  templateUrl: './contactustab.component.html',
  styleUrls: ['./contactustab.component.css']
})
export class ContactustabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
